# Cloud HP by Yov

Panel website mobile-first untuk membuka layar Android virtual yang di-host terpisah.

## Penting sebelum mulai
- Website ini **bukan** emulator Android dengan sendirinya. `public/` adalah panel web.
- Emulator contoh menggunakan Docker image pihak ketiga `budtmo/docker-android`. Periksa dokumentasi dan ketersediaan tag image sebelum dipakai.
- Untuk sesi 24/7, server harus tetap menyala. Hosting website statis gratis tidak menjalankan emulator Android.
- File `docker-compose.yml` hanya mengikat port ke `127.0.0.1` agar tidak langsung terbuka ke internet. Jangan mengubahnya menjadi `0.0.0.0` tanpa memasang autentikasi, firewall, dan HTTPS.

## A. Jalankan website panel di Android (uji lokal)
1. Ekstrak folder `cloud_hp_by_yov`.
2. Buka `public/index.html` di browser atau unggah isi folder `public` ke hosting statis.
3. Panel akan tampil, tetapi layar virtual belum aktif sampai kamu punya server Android.

## B. Jalankan emulator di server Linux
Kebutuhan umumnya: Linux x86_64, Docker + Docker Compose, virtualisasi/KVM yang berfungsi, RAM cukup (disarankan 8 GB atau lebih untuk percobaan), dan penyedia yang mengizinkan nested virtualization.

1. Pasang Docker Engine dan Docker Compose sesuai dokumentasi resmi Docker untuk distro server.
2. Salin `docker-compose.yml` ke server.
3. Pastikan KVM tersedia: `ls -l /dev/kvm`
4. Jalankan: `docker compose up -d`
5. Lihat log: `docker compose logs -f android`
6. Uji dari server itu sendiri, sesuai port web VNC yang didokumentasikan image. Pada konfigurasi ini port 6080 hanya terikat ke localhost.

**Jangan** mengekspos VNC/ADB langsung ke internet. Untuk akses jarak jauh, gunakan VPN pribadi (misalnya WireGuard/Tailscale) atau reverse proxy HTTPS dengan autentikasi yang benar. Setelah akses aman disiapkan, masukkan URL web VNC yang bisa kamu akses ke panel.

## C. Menghubungkan panel
1. Buka website Cloud HP.
2. Masukkan URL web VNC/noVNC yang aman dan dapat dijangkau browser HP.
3. Tekan **Hubungkan layar**.
4. Jika iframe ditolak oleh kebijakan server, tekan **Buka tab baru**.

Panel ini hanya memuat URL remote; dukungan iframe tergantung konfigurasi server. Menghubungkan layar tidak menjamin semua kontrol sentuh/clipboard akan didukung oleh image server.

## Opsi biaya
- Panel web statis: dapat di-host gratis.
- Emulator Android 24/7: biasanya perlu server berbayar atau perangkat/server milik sendiri yang terus hidup. Free tier dapat tidur, membatasi jam, atau tidak mendukung KVM.
- Jika ingin benar-benar tanpa biaya, coba emulator lokal di perangkat/komputer yang tersedia, tetapi ia tidak akan tetap berjalan saat perangkat tersebut dimatikan.

## Keamanan
- Gunakan hanya server dan akun milik sendiri.
- Jangan taruh token, password, atau private key di `public/app.js`.
- Gunakan HTTPS dan autentikasi; lindungi dashboard remote.
- Hentikan emulator jika tidak digunakan untuk menghemat biaya.
