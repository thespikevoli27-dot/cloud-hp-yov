const $ = (id) => document.getElementById(id);
const urlInput = $("serverUrl");
const remoteArea = $("remoteArea");
const remoteFrame = $("remoteFrame");
let currentUrl = "";

function validHttpUrl(value) {
  try {
    const url = new URL(value);
    return (url.protocol === "https:" || url.protocol === "http:") && !!url.hostname;
  } catch (_) {
    return false;
  }
}

function setConnected(connected, message) {
  $("deviceStatus").textContent = connected ? "Layar terhubung" : "Belum tersambung";
  $("sessionStatus").textContent = connected ? "Panel tersambung" : "Menunggu server";
  $("connectionStatus").textContent = connected ? "Alamat dimuat" : "Belum dikonfigurasi";
  $("statusPill").classList.toggle("online", connected);
  $("statusPill").innerHTML = connected ? "<i></i> Terhubung" : "<i></i> Offline";
  $("screenMessage").textContent = message;
}

$("connectBtn").addEventListener("click", () => {
  const value = urlInput.value.trim();
  if (!validHttpUrl(value)) {
    alert("Masukkan alamat server yang valid, diawali https:// atau http://.");
    urlInput.focus();
    return;
  }
  currentUrl = new URL(value).href;
  remoteFrame.src = currentUrl;
  remoteArea.classList.remove("hidden");
  setConnected(true, "Layar remote sudah dimuat. Jika tidak tampil, buka melalui tab baru.");
  remoteArea.scrollIntoView({ behavior: "smooth", block: "start" });
});

$("clearBtn").addEventListener("click", () => {
  remoteFrame.src = "about:blank";
  remoteArea.classList.add("hidden");
  currentUrl = "";
  setConnected(false, "Masukkan alamat server Android untuk menghubungkan layar.");
});

$("openTabBtn").addEventListener("click", () => {
  if (currentUrl) window.open(currentUrl, "_blank", "noopener,noreferrer");
});

setConnected(false, "Masukkan alamat server Android untuk menghubungkan layar.");
